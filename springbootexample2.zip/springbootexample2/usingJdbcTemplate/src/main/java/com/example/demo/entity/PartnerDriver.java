package com.example.demo.entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.ToString;
import lombok.extern.slf4j.*;

@ToString
@Slf4j
@Data
@AllArgsConstructor
public class PartnerDriver {
	public int driverid;
	public String drivername;
	public String MobileNo;
	public String Rating;
}
