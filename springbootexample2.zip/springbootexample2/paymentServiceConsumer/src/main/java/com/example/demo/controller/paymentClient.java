package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.discovery.EurekaClient;

@RestController
public class paymentClient {
	
	@Autowired
	RestTemplate template;
	
	@Autowired
	private EurekaClient client;
	
	@GetMapping("/showOnePayment")
	public String getPayment()
	{
		String url="http://payment-detail-service/showPayment";
		return template.getForObject(url, String.class);
		//return template.getForObject("http://localhost:8080/showPayment", String.class);
	}

}
