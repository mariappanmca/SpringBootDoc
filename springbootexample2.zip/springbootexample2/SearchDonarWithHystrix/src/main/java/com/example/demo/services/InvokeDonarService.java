package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class InvokeDonarService {

	@Autowired
	public RestTemplate template;
	
	@Autowired
	LoadBalancerClient balancedClient;
	
	
	@HystrixCommand(fallbackMethod="myFallBack")
	public String invoke(String bloodGroup)
	{
		System.out.println("Normal flow Executed");
		ServiceInstance instance=balancedClient.choose("search-blood-donar");
		System.out.println(instance.getUri());
		
		String baseUrl=instance.getUri().toString();
		
		baseUrl=baseUrl+"/search/"+bloodGroup+"";
		String response=template.getForObject(baseUrl, String.class);
				return response;
				
		//String response=template.getForObject("http://localhost", String.class)
	}
	
	public String myFallBack(String bloodGroup)
	{
		System.out.println("Fallback method called");
		return "Service down";
	}
}
